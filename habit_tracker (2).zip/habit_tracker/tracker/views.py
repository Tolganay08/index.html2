from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count, Q
from datetime import date, timedelta
from .models import Goal, Habit, HabitCompletion, CustomUser
from .forms import CustomUserCreationForm, CustomAuthenticationForm, GoalForm, HabitForm
from datetime import date

def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Тіркелу сәтті аяқталды!')
            return redirect('dashboard')
    else:
        form = CustomUserCreationForm()
    return render(request, 'tracker/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user = authenticate(email=email, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, 'Кіру сәтті аяқталды!')
                return redirect('dashboard')
    else:
        form = CustomAuthenticationForm()
    return render(request, 'tracker/login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.success(request, 'Сіз жүйеден шықтыңыз.')
    return redirect('login')

@login_required
def dashboard(request):
    goals = Goal.objects.filter(user=request.user)
    total_goals = goals.count()
    completed_goals = goals.filter(status='completed').count()
    active_goals = goals.filter(status='active').count()

    habits = Habit.objects.filter(user=request.user, is_active=True)
    total_habits = habits.count()

    today = date.today()
    today_completions = HabitCompletion.objects.filter(
        habit__user=request.user,
        date=today,
        completed=True
    ).count()
    
    week_dates = [today - timedelta(days=i) for i in range(6, -1, -1)]
    week_completions = []
    for day in week_dates:
        count = HabitCompletion.objects.filter(
            habit__user=request.user,
            date=day,
            completed=True
        ).count()
        week_completions.append({
            'date': day,
            'count': count,
            'day_name': day.strftime('%A')[:3]
        })
    
    upcoming_goals = goals.filter(
        deadline__gte=today,
        status='active'
    ).order_by('deadline')[:5]

    daily_habits = habits.filter(frequency='daily')[:5]
    
    context = {
        'total_goals': total_goals,
        'completed_goals': completed_goals,
        'active_goals': active_goals,
        'total_habits': total_habits,
        'today_completions': today_completions,
        'week_completions': week_completions,
        'upcoming_goals': upcoming_goals,
        'daily_habits': daily_habits,
    }
    return render(request, 'tracker/dashboard.html', context)

@login_required
def goal_list(request):
    goals = Goal.objects.filter(user=request.user).order_by('-created_at')
    
    context = {
        'goals': goals,
        'today': date.today() 
    }
    return render(request, 'tracker/goal_list.html', context)

@login_required
def goal_create(request):
    if request.method == 'POST':
        form = GoalForm(request.POST)
        if form.is_valid():
            goal = form.save(commit=False)
            goal.user = request.user
            goal.save()
            messages.success(request, 'Мақсат сәтті қосылды!')
            return redirect('goal_list')
    else:
        form = GoalForm()
    return render(request, 'tracker/goal_form.html', {'form': form, 'title': 'Жаңа мақсат'})

@login_required
def goal_edit(request, pk):
    goal = get_object_or_404(Goal, pk=pk, user=request.user)
    if request.method == 'POST':
        form = GoalForm(request.POST, instance=goal)
        if form.is_valid():
            form.save()
            messages.success(request, 'Мақсат сәтті өзгертілді!')
            return redirect('goal_list')
    else:
        form = GoalForm(instance=goal)
    return render(request, 'tracker/goal_form.html', {'form': form, 'title': 'Мақсатты өзгерту'})

@login_required
def goal_delete(request, pk):
    goal = get_object_or_404(Goal, pk=pk, user=request.user)
    if request.method == 'POST':
        goal.delete()
        messages.success(request, 'Мақсат сәтті жойылды!')
        return redirect('goal_list')
    return render(request, 'tracker/goal_confirm_delete.html', {'goal': goal})

@login_required
def habit_list(request):
    habits = Habit.objects.filter(user=request.user).order_by('-start_date')
    
    for habit in habits:
        completions = HabitCompletion.objects.filter(habit=habit, completed=True).count()
        habit.completion_rate = (completions / habit.target_days * 100) if habit.target_days > 0 else 0
        habit.completions_count = completions

        today = date.today()
        habit.today_completed = HabitCompletion.objects.filter(
            habit=habit,
            date=today,
            completed=True
        ).exists()
    
    return render(request, 'tracker/habit_list.html', {'habits': habits})

@login_required
def habit_create(request):
    if request.method == 'POST':
        form = HabitForm(request.POST)
        if form.is_valid():
            habit = form.save(commit=False)
            habit.user = request.user
            habit.save()
            messages.success(request, 'Әдет сәтті қосылды!')
            return redirect('habit_list')
    else:
        form = HabitForm()
    return render(request, 'tracker/habit_form.html', {'form': form, 'title': 'Жаңа әдет'})

@login_required
def habit_edit(request, pk):
    habit = get_object_or_404(Habit, pk=pk, user=request.user)
    if request.method == 'POST':
        form = HabitForm(request.POST, instance=habit)
        if form.is_valid():
            form.save()
            messages.success(request, 'Әдет сәтті өзгертілді!')
            return redirect('habit_list')
    else:
        form = HabitForm(instance=habit)
    return render(request, 'tracker/habit_form.html', {'form': form, 'title': 'Әдетті өзгерту'})

@login_required
def habit_delete(request, pk):
    habit = get_object_or_404(Habit, pk=pk, user=request.user)
    if request.method == 'POST':
        habit.delete()
        messages.success(request, 'Әдет сәтті жойылды!')
        return redirect('habit_list')
    return render(request, 'tracker/habit_confirm_delete.html', {'habit': habit})

@login_required
def habit_toggle_completion(request, pk):
    habit = get_object_or_404(Habit, pk=pk, user=request.user)
    today = date.today()
    
    completion, created = HabitCompletion.objects.get_or_create(
        habit=habit,
        date=today,
        defaults={'completed': True}
    )
    
    if not created:
        completion.completed = not completion.completed
        completion.save()
    
    if completion.completed:
        messages.success(request, f'"{habit.title}" әдеті орындалды деп белгіленді!')
    else:
        messages.info(request, f'"{habit.title}" әдеті орындалмады деп белгіленді.')
    
    return redirect('habit_list')

@login_required
def profile_view(request):
    user = request.user
    if request.method == 'POST':
        user.name = request.POST.get('name')
        user.save()
        messages.success(request, 'Профиль сәтті жаңартылды!')
        return redirect('profile')
    
    return render(request, 'tracker/profile.html', {'user': user})