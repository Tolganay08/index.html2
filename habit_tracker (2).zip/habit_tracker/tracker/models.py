from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.utils import timezone

class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('Email міндетті')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(email, password, **extra_fields)

class CustomUser(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(unique=True)
    name = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)
    
    objects = CustomUserManager()
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['name']
    
    def __str__(self):
        return self.email

class Goal(models.Model):
    GOAL_TYPES = [
        ('short', 'Қысқа мерзімді'),
        ('long', 'Ұзақ мерзімді'),
        ('daily', 'Күнделікті'),
    ]
    
    STATUS_CHOICES = [
        ('active', 'Белсенді'),
        ('completed', 'Орындалды'),
        ('pending', 'Күтілуде'),
        ('cancelled', 'Бас тартылды'),
    ]
    
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='goals')
    title = models.CharField(max_length=200, verbose_name="Тақырып")
    description = models.TextField(verbose_name="Сипаттама")
    goal_type = models.CharField(max_length=20, choices=GOAL_TYPES, verbose_name="Мақсат түрі")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active', verbose_name="Статус")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    deadline = models.DateField(null=True, blank=True, verbose_name="Мерзімі")
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.title} - {self.user.email}"

class Habit(models.Model):
    FREQUENCY_CHOICES = [
        ('daily', 'Күнде'),
        ('weekly', 'Аптасына'),
        ('monthly', 'Айына'),
        ('weekdays', 'Жұмыс күндері'),
        ('weekends', 'Демалыс күндері'),
    ]
    
    CATEGORY_CHOICES = [
        ('health', 'Денсаулық'),
        ('study', 'Оқу'),
        ('work', 'Жұмыс'),
        ('sport', 'Спорт'),
        ('finance', 'Қаржы'),
        ('other', 'Басқа'),
    ]
    
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='habits')
    title = models.CharField(max_length=200, verbose_name="Тақырып")
    description = models.TextField(blank=True, verbose_name="Сипаттама")
    frequency = models.CharField(max_length=20, choices=FREQUENCY_CHOICES, verbose_name="Жиілік")
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, verbose_name="Санат")
    is_active = models.BooleanField(default=True, verbose_name="Белсенді")
    start_date = models.DateField(default=timezone.now, verbose_name="Басталу күні")
    target_days = models.IntegerField(default=30, verbose_name="Мақсаттық күн саны")
    
    icon = models.CharField(max_length=50, default='fas fa-target', verbose_name="Иконка")
    
    class Meta:
        ordering = ['-start_date']
    
    def __str__(self):
        return f"{self.title} - {self.user.email}"

class HabitCompletion(models.Model):
    habit = models.ForeignKey(Habit, on_delete=models.CASCADE, related_name='completions')
    date = models.DateField(default=timezone.now)
    completed = models.BooleanField(default=True)
    notes = models.TextField(blank=True, verbose_name="Ескертпелер")
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['habit', 'date']
        ordering = ['-date']
    
    def __str__(self):
        return f"{self.habit.title} - {self.date}"