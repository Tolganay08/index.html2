from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, Goal, Habit
from django.contrib.auth import authenticate

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Электрондық пошта'})
    )
    password1 = forms.CharField(
        label="Құпия сөз",
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Құпия сөз'})
    )
    password2 = forms.CharField(
        label="Құпия сөзді қайталаңыз",
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Құпия сөзді қайталаңыз'})
    )
    
    class Meta:
        model = CustomUser
        fields = ('email', 'name')
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Аты-жөні'}),
        }

class CustomAuthenticationForm(forms.Form):
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Электрондық пошта'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Құпия сөз'})
    )
    
    def clean(self):
        email = self.cleaned_data.get('email')
        password = self.cleaned_data.get('password')
        
        if email and password:
            self.user = authenticate(email=email, password=password)
            if self.user is None:
                raise forms.ValidationError('Электрондық пошта немесе құпия сөз дұрыс емес')
        return self.cleaned_data

class GoalForm(forms.ModelForm):
    class Meta:
        model = Goal
        fields = ['title', 'description', 'goal_type', 'deadline', 'status']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Мақсат тақырыбы'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Мақсат сипаттамасы'}),
            'goal_type': forms.Select(attrs={'class': 'form-control'}),
            'deadline': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'status': forms.Select(attrs={'class': 'form-control'}),
        }

class HabitForm(forms.ModelForm):
    ICON_CHOICES = [
        ('fas fa-dumbbell', '🏋️‍♂️ Спорт'),
        ('fas fa-book', '📚 Оқу'),
        ('fas fa-running', '🏃 Жүгіру'),
        ('fas fa-apple-alt', '🍎 Денсаулық'),
        ('fas fa-money-bill-wave', '💰 Қаржы'),
        ('fas fa-briefcase', '💼 Жұмыс'),
        ('fas fa-heart', '❤️ Денсаулық'),
        ('fas fa-brain', '🧠 Дамыту'),
        ('fas fa-moon', '🌙 Ұйқы'),
        ('fas fa-utensils', '🍽️ Тамақтану'),
        ('fas fa-water', '💧 Су'),
        ('fas fa-meditation', '🧘‍♂️ Медитация'),
        ('fas fa-pencil-alt', '✏️ Жазу'),
        ('fas fa-music', '🎵 Музыка'),
        ('fas fa-language', '🗣️ Тіл'),
    ]
    
    icon = forms.ChoiceField(choices=ICON_CHOICES, widget=forms.Select(attrs={'class': 'form-control'}))
    
    class Meta:
        model = Habit
        fields = ['title', 'description', 'frequency', 'category', 'target_days', 'start_date', 'icon']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Әдет тақырыбы'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Әдет сипаттамасы'}),
            'frequency': forms.Select(attrs={'class': 'form-control'}),
            'category': forms.Select(attrs={'class': 'form-control'}),
            'target_days': forms.NumberInput(attrs={'class': 'form-control'}),
            'start_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        }